import './App.css'
import { Button } from './components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card'
import { Badge } from './components/ui/badge'
import { ArrowRight, Target, Globe, Users, CheckCircle, Calendar, Rocket, TrendingUp } from 'lucide-react'
import heroImage from './assets/Zs0tIATm6sfB.jpg'
import businessImage from './assets/L7Y7LxmQ3eFe.jpg'
import aiImage from './assets/Dg7xfLu2cCzq.jpg'

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 to-blue-900/90" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Your AI-powered
            <span className="block text-blue-400">growth partner</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Unlock unparalleled sales and lead generation with NS Growth's hybrid model, 
            designed for B2B companies ready to scale globally.
          </p>
          <Button 
            size="lg" 
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Book a Strategy Call
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* How We Help Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">How We Help</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our unique hybrid model combines AI-driven efficiency with human expertise 
              to deliver sustainable, predictable growth for your business.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors">
                  <Target className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl font-bold">Qualified Meetings on Autopilot</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 leading-relaxed">
                  Transform your sales pipeline with a consistent flow of pre-qualified leads. 
                  Our AI-driven outreach ensures your sales team spends less time prospecting 
                  and more time closing deals.
                </CardDescription>
                <Badge variant="secondary" className="mt-4">Recurring Monthly Retainer</Badge>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-200 transition-colors">
                  <Globe className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl font-bold">Market Entry Accelerator</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 leading-relaxed">
                  Expand into new international markets with confidence. Our comprehensive 
                  solution provides strategic planning, localized outreach, and expert 
                  market insights for rapid penetration.
                </CardDescription>
                <Badge variant="secondary" className="mt-4">Premium Service</Badge>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                  <Users className="h-8 w-8 text-purple-600" />
                </div>
                <CardTitle className="text-xl font-bold">Sales Team-in-a-Box</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 leading-relaxed">
                  Build and scale your sales force efficiently. We recruit, train, and manage 
                  remote sales representatives supported by AI tools for optimal performance 
                  and seamless integration.
                </CardDescription>
                <Badge variant="secondary" className="mt-4">Fully Managed</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Our Process</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A systematic approach that combines AI-driven insights with human expertise 
              at every stage of your growth journey.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Discover",
                description: "In-depth analysis of your business, target market, and growth objectives using AI-powered insights.",
                icon: <TrendingUp className="h-6 w-6" />
              },
              {
                step: "02", 
                title: "Outreach",
                description: "Highly personalized campaigns across multiple channels using advanced AI algorithms.",
                icon: <Target className="h-6 w-6" />
              },
              {
                step: "03",
                title: "Meetings",
                description: "Rigorous qualification process ensuring every meeting is with genuinely interested prospects.",
                icon: <Calendar className="h-6 w-6" />
              },
              {
                step: "04",
                title: "Scale",
                description: "Building repeatable, scalable processes with continuous optimization based on performance data.",
                icon: <Rocket className="h-6 w-6" />
              }
            ].map((item, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto text-white group-hover:bg-blue-700 transition-colors">
                    {item.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-gray-900 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {item.step}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose NS Growth Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8">
                Why Choose NS Growth?
              </h2>
              <div className="space-y-6">
                {[
                  {
                    title: "AI-Powered Efficiency",
                    description: "Proprietary AI models optimize every stage of sales and lead generation for higher conversion rates and reduced costs."
                  },
                  {
                    title: "Global Talent Network", 
                    description: "Access to highly skilled sales professionals and market specialists worldwide for your expansion goals."
                  },
                  {
                    title: "Proven Systems & Methodologies",
                    description: "Battle-tested systems refined through years of experience and continuous data analysis for predictable success."
                  },
                  {
                    title: "End-to-End Partnership",
                    description: "We act as an extension of your team, providing comprehensive support and strategic guidance at every step."
                  },
                  {
                    title: "Focus on Trust & Clarity",
                    description: "Transparent communication and measurable outcomes without hype, focusing on clear value propositions."
                  }
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <CheckCircle className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img 
                src={businessImage} 
                alt="Professional business team" 
                className="rounded-lg shadow-xl w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent rounded-lg" />
            </div>
          </div>
        </div>
      </section>

      {/* Case Examples Section */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Case Examples</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real results from real companies. See how NS Growth has empowered 
              B2B businesses to achieve their ambitious growth targets.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "SaaS Scales to Nordics",
                description: "A rapidly growing SaaS company penetrated the Nordic market using our Market Entry Accelerator, securing 15 new enterprise accounts within six months.",
                metric: "15 New Accounts",
                timeframe: "6 Months"
              },
              {
                title: "Agency Doubles Deal Flow", 
                description: "A digital marketing agency implemented our Qualified Meetings on Autopilot and saw a 100% increase in qualified sales meetings within three months.",
                metric: "100% Increase",
                timeframe: "3 Months"
              },
              {
                title: "Manufacturing Firm Optimizes Sales",
                description: "A traditional manufacturing company modernized with our Sales Team-in-a-Box, achieving 30% faster sales cycles and 20% larger deals.",
                metric: "30% Faster Cycles",
                timeframe: "Ongoing"
              }
            ].map((item, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-gray-900">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 mb-4 leading-relaxed">
                    {item.description}
                  </CardDescription>
                  <div className="flex justify-between items-center">
                    <Badge variant="outline" className="text-blue-600 border-blue-600">
                      {item.metric}
                    </Badge>
                    <span className="text-sm text-gray-500">{item.timeframe}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-to-br from-blue-900 to-slate-900 text-white relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{ backgroundImage: `url(${aiImage})` }}
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Accelerate Your Growth?
          </h2>
          <p className="text-xl mb-8 text-gray-200 max-w-3xl mx-auto leading-relaxed">
            Don't let untapped potential hold your business back. Partner with NS Growth 
            and transform your sales strategy into a powerful engine for sustainable expansion.
          </p>
          <Button 
            size="lg" 
            className="bg-white text-blue-900 hover:bg-gray-100 px-8 py-4 text-lg rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Book Your Free Strategy Call Today!
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">NS Growth</h3>
              <p className="text-gray-400 leading-relaxed">
                Your AI-powered growth partner for sustainable business expansion 
                and international market penetration.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-gray-400">
                <p>Email: nicklas@ns-growth.se</p>
                <p>Website: ns-growth.se</p>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  LinkedIn
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  Twitter
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 NS Growth. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
